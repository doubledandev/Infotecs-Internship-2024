#!/bin/bash

# Workdit for Vagrant
WORKDIR="./vagrant-debian11"
mkdir -p "$WORKDIR"
cd "$WORKDIR" || exit

# Creating VM with Vagrant
if [ ! -f "Vagrantfile" ]; then
    vagrant init debian/bullseye64

    cat <<EOF > Vagrantfile
ENV['VAGRANT_DEFAULT_PROVIDER'] = 'virtualbox'
#Bypassing Vagrant Cloud blocking in Russia
ENV['VAGRANT_SERVER_URL'] = 'https://vagrant.elab.pro'

Vagrant.configure("2") do |config|
  config.vm.define "Debian11_VM" do |vm_conf|
    vm_conf.vm.box = "debian/bullseye64"
    vm_conf.vm.provider "virtualbox" do |vb|
      vb.name = "VagrantVM"
      vb.gui = false
      vb.memory = 1024
      vb.cpus = 1
    end
  end
end
EOF
    echo "Vagrantfile initialized"
else
    echo "Vagrantfile already exists. Skipping..."
fi

vagrant up

# Choosing whether user wants to connect to VM
read -p "Hey, infotecs user, do you want to connect to VM? (y/n):" answer
answer=$(echo "$answer" | tr '[:upper:]' '[:lower:]')

if [[ "$answer" == "y" || "$answer" == "yes" ]]; then
 echo "Of course you are! Connecting..."
 vagrant ssh
fi
